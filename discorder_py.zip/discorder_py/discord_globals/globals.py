import discord
from discord.ext import commands


embed=discord.Embed
red=discord.Color.red()
blue=discord.Color.blue()